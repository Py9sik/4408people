#ifndef PLOSCHAD_H
#define PLOSCHAD_H


class ploschad
{
    public:
        ploschad();
        virtual ~ploschad();

    protected:

    private:
};

#endif
