#include <iostream>
#include "ploschad.h"

template<typename T> class Class{
private:
    T first;
    T second;
public:
    T Pair(T a, T b){
        first = a;
        second = b;
        }
    void srav(){
        T a = first>second?first:second;
        std::cout<<a;
    }
};


int main()
{
    system("color fd");
    system("title xpeHb");
    int a1 = 5, b1 = 23;
    double a2 = 4.5, b2 = 9.8;
    char a3 = 'a', b3 = 'b';
    std::string a4 = "string", b4 = "strina";

}
