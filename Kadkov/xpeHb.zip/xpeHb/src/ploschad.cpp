#include "ploschad.h"

class ploshad{
double length, heigth;
ploshad::ploshad(){}
ploshad::~ploshad(double p_length, double p_heigth)
    {
        length = p_length;
        heigth = p_heigth;
    }

private:

    void print_result(double result){
        std::cout<<"Area of figure is "<<result;
    };

public:

    void square(){
        double result = length * heigth;
        print_result(result);
    };
    void treangel(){};
    void circle();
}
